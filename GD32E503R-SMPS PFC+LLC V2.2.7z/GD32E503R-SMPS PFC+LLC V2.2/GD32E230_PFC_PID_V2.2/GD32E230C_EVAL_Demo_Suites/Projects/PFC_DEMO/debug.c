/*!
    \file  debug.c
    \brief debug driver file

    \version 2019-07-15, V1.0.0, FOC demo
*/

/*
    Copyright (c) 2019, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/


#include "debug.h"

/* static function declaration */
#ifdef USART_DEBUG_ENABLE
static void usart_config(void);
#endif /* USART_DEBUG_ENABLE */
#ifdef DAC_DEBUG_ENABLE
static void dac_config(void);
#endif /* DAC_DEBUG_ENABLE */

/* debug variables */
static int8_t syn_data[21];




/*!
    \brief      initialize the hardware of debug function
    \param[in]  none
    \param[out] none
    \retval     none
*/
void debug_init(void)
{
    usart_config();
}

/*!
    \brief      data transmission with USART
    \param[in]  usart_data: the data to be sent
    \param[out] none
    \retval     none
*/
/* data buffer of usart debug */
void debug_usart_data_transfer(mc_usart_debug usart_data)
{
    static uint8_t dma_flag = 0;
    uint8_t data_index = 0, i;
    int8_t sum = 0;

    if(dma_flag ==0){
        syn_data[data_index++] = 0xAA;
        syn_data[data_index++] = 0xAA;
        syn_data[data_index++] = 0xF1;
        syn_data[data_index++] = 8;

        syn_data[data_index++] = usart_data.data1 >> 8;
        syn_data[data_index++] = usart_data.data1;
        syn_data[data_index++] = usart_data.data2 >> 8;
        syn_data[data_index++] = usart_data.data2;
        syn_data[data_index++] = usart_data.data3 >> 8;
        syn_data[data_index++] = usart_data.data3;
        syn_data[data_index++] = usart_data.data4 >> 8;
        syn_data[data_index++] = usart_data.data4;
//        syn_data[data_index++] = usart_data.data5 >> 8;
//        syn_data[data_index++] = usart_data.data5;
//        syn_data[data_index++] = usart_data.data6 >> 8;
//        syn_data[data_index++] = usart_data.data6;
//        syn_data[data_index++] = usart_data.data7 >> 8;
//        syn_data[data_index++] = usart_data.data7;
//        syn_data[data_index++] = usart_data.data8 >> 8;
//        syn_data[data_index++] = usart_data.data8;

        for(i=0;i<12;i++){
            sum += syn_data[i];
        }
        syn_data[data_index]=sum;

        dma_channel_enable(DMA_CH1);
        dma_flag = 1;
        data_index = 0;
    }

    if(dma_flag_get(DMA_CH1,DMA_FLAG_FTF) == SET){
        dma_flag_clear(DMA_CH1,DMA_FLAG_FTF);
        dma_channel_disable(DMA_CH1);
        DMA_CH1CNT = 13;
        dma_channel_enable(DMA_CH1);
        dma_flag = 0;
    }
}

/*!
    \brief      configure USART
    \param[in]  none
    \param[out] none
    \retval     none
*/
static void usart_config(void)
{
    dma_parameter_struct dma_init_struct;

    /* clock enable */
    rcu_periph_clock_enable(RCU_GPIOA);
    /* USART1_RX: PA6 */
    gpio_mode_set(USART_RX_PORT,GPIO_MODE_AF,GPIO_PUPD_NONE,USART_RX_PIN);
    gpio_af_set(USART_RX_PORT,GPIO_AF_0,USART_RX_PIN);
    /* USART1_TX: PA7 */
    gpio_mode_set(USART_TX_PORT,GPIO_MODE_AF,GPIO_PUPD_NONE,USART_TX_PIN);
    gpio_af_set(USART_TX_PORT,GPIO_AF_0,USART_TX_PIN);

    /* clock enable */
    rcu_periph_clock_enable(DEBUG_USART_CLOCK);

    /* USART0 configure */
    usart_deinit(DEBUG_USART);
    usart_baudrate_set(DEBUG_USART, USART_BPS);
    usart_stop_bit_set(DEBUG_USART, USART_STB_1BIT);
    usart_word_length_set(DEBUG_USART, USART_WL_8BIT);
    usart_parity_config(DEBUG_USART, USART_PM_NONE);
    usart_hardware_flow_rts_config(DEBUG_USART, USART_RTS_DISABLE);
    usart_hardware_flow_cts_config(DEBUG_USART, USART_CTS_DISABLE);
    usart_receive_config(DEBUG_USART, USART_RECEIVE_ENABLE);
    usart_transmit_config(DEBUG_USART, USART_TRANSMIT_ENABLE);

    usart_flag_clear(DEBUG_USART, USART_FLAG_TC);
    usart_dma_transmit_config(DEBUG_USART, USART_DENT_ENABLE);
    usart_enable(DEBUG_USART);

    /* clock enable */
    rcu_periph_clock_enable(RCU_DMA);
    /* USART */
    dma_deinit(DMA_CH1);
    dma_init_struct.direction    = DMA_MEMORY_TO_PERIPHERAL;
    dma_init_struct.memory_addr  = (uint32_t)syn_data;//(uint32_t)buffer;
    dma_init_struct.memory_inc   = DMA_MEMORY_INCREASE_ENABLE;
    dma_init_struct.memory_width = DMA_MEMORY_WIDTH_8BIT;
    dma_init_struct.number       = 11;//DEBUG_BUFFER_SIZE*12;
    dma_init_struct.periph_addr  = (uint32_t)0x40013828;
    dma_init_struct.periph_inc   = DMA_PERIPH_INCREASE_DISABLE;
    dma_init_struct.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    dma_init_struct.priority     = DMA_PRIORITY_ULTRA_HIGH;
    dma_init(DMA_CH1, &dma_init_struct);
    dma_circulation_disable(DMA_CH1);
    dma_memory_to_memory_disable(DMA_CH1);
    dma_interrupt_enable(DMA_CH1,DMA_INT_FTF);
    dma_channel_enable(DMA_CH1);
}
