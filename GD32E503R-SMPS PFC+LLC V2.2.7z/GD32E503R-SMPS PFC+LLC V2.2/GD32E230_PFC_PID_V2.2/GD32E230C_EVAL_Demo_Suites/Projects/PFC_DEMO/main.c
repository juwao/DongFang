/*!
    \file    main.c
    \brief   PFC V2.2 example
    
    \version 2023-02-08, V1.1.0, firmware for GD32E23x
*/

/*
    Copyright (c) 2020, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "systick.h"
#include "main.h"
#include "gd32e230c_eval.h"
#include "pid.h"
#include "debug.h"


uint16_t Vout_value,g16sample_cnt,g16Vout_OVP,g16Vout_OCP;
uint8_t  Start_button_flag;
uint8_t	 pid_vout_calc_enable_flag, pid_current_calc_enable_flag;
uint16_t g16pwm_duty,g16pwm_test;
uint8_t  g8PFCStatusFlag;
uint16_t flag_run_time;
uint8_t  g8Vin_enable, g8Vin_add_pid;
float32  gf32Vout_value,actual_current_temp;
float32  gf32Vin_max_bak, gf32Vin_min_bak,gf32Vin_offset,gf32Vin_average,gf32Vin_max,gf32Vin_min;
uint8_t  check_vin_parameter_enable;
uint8_t  g8trigCurrentPID, g8trigOVP,g8sample_init_over;
uint8_t  g8temp_protect_flag;

uint16_t g16step_cnt,g16temp_cnt,g16delay;

float32 actual_current,actual_vin,actual_vin_average,actual_vin_offset;
float32 k,m,g16pwm_duty_para;
/*!
    \brief      RCU configuration
    \param[in]  none
    \param[out] none
    \retval     none
*/
static void rcu_config(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_GPIOC);

    rcu_periph_clock_enable(RCU_ADC);
    rcu_periph_clock_enable(RCU_TIMER0);
    rcu_adc_clock_config(RCU_ADCCK_AHB_DIV3);
}

/**
    \brief      configure the GPIO ports
    \param[in]  none
    \param[out] none
    \retval     none
  */
void gpio_config(void)
{
    /*configure PA8(TIMER0/CH0) as alternate function*/
    gpio_mode_set(PFC_DRIVER_PORT, GPIO_MODE_AF, GPIO_PUPD_NONE, PFC_DRIVER_PIN);
    gpio_output_options_set(PFC_DRIVER_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ,PFC_DRIVER_PIN);
    gpio_af_set(PFC_DRIVER_PORT, GPIO_AF_2, PFC_DRIVER_PIN);

    /* configure button pin as input */
    gpio_mode_set(K2_BUTTON_PORT, GPIO_MODE_INPUT, GPIO_PUPD_NONE, K2_BUTTON_PIN);
    gpio_mode_set(K3_BUTTON_PORT, GPIO_MODE_INPUT, GPIO_PUPD_NONE, K3_BUTTON_PIN);
    
    /* configure LED GPIO port */ 
    gpio_mode_set(LED1_DEBUG_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, LED1_DEBUG_PIN);
    gpio_output_options_set(LED1_DEBUG_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, LED1_DEBUG_PIN);
    gpio_mode_set(LED2_DEBUG_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, LED2_DEBUG_PIN);
    gpio_output_options_set(LED2_DEBUG_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, LED2_DEBUG_PIN);
    /* reset LED GPIO pin */
    gpio_bit_reset(LED1_DEBUG_PORT,LED1_DEBUG_PIN);
    gpio_bit_reset(LED2_DEBUG_PORT,LED2_DEBUG_PIN);

    /* configure BUZZER GPIO port */ 
    gpio_mode_set(BUZZER_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, BUZZER_PIN);
    gpio_output_options_set(BUZZER_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, BUZZER_PIN);
    /* reset BUZZER GPIO pin */
    gpio_bit_reset(BUZZER_PORT,BUZZER_PIN);

    /* configure FAN GPIO port */ 
    gpio_mode_set(FAN_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, FAN_PIN);
    gpio_output_options_set(FAN_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, FAN_PIN);
    /* reset BUZZER GPIO pin */
    gpio_bit_set(FAN_PORT,FAN_PIN);

    /* config the GPIO as analog mode */
    gpio_mode_set(PFC_VS_PORT, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, PFC_VS_PIN);
    gpio_mode_set(PFC_CS2_PORT, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, PFC_CS2_PIN);
    gpio_mode_set(VAC_PFC_SENSE2_PORT, GPIO_MODE_ANALOG, GPIO_PUPD_NONE, VAC_PFC_SENSE2_PIN);

    /* configure PFC-LLC communication port */
    gpio_mode_set(PFC_READY_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PFC_READY_PIN);
    gpio_output_options_set(PFC_READY_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, PFC_READY_PIN);
    gpio_bit_reset(PFC_READY_PORT ,PFC_READY_PIN);
    gpio_mode_set(PFC_RES_PORT, GPIO_MODE_INPUT, GPIO_PUPD_NONE, PFC_RES_PIN);

    gpio_mode_set(PFC_TX1_PORT, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, PFC_TX1_PIN);
    gpio_output_options_set(PFC_TX1_PORT, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, PFC_TX1_PIN);
    gpio_bit_reset(PFC_TX1_PORT ,PFC_TX1_PIN);

}

/*!
    \brief      configure the ADC peripheral
    \param[in]  none
    \param[out] none
    \retval     none
*/
void adc_config(void)
{
    /* ADC continuous function disable */
    adc_special_function_config(ADC_CONTINUOUS_MODE, DISABLE);
    /* ADC scan function disable */
    adc_special_function_config(ADC_SCAN_MODE, ENABLE);
    /* ADC data alignment config */
    adc_data_alignment_config(ADC_DATAALIGN_RIGHT);

    /* ADC channel length config */
    adc_channel_length_config( ADC_INSERTED_CHANNEL, 3U);
    adc_inserted_channel_config(0, ADC_CHANNEL_1, ADC_SAMPLETIME_1POINT5);
    adc_inserted_channel_config(1, ADC_CHANNEL_3, ADC_SAMPLETIME_1POINT5);
    adc_inserted_channel_config(2, ADC_CHANNEL_0, ADC_SAMPLETIME_1POINT5);

    /* ADC trigger config */
    adc_external_trigger_source_config(ADC_INSERTED_CHANNEL, ADC_EXTTRIG_INSERTED_T0_CH3); 
    /* ADC external trigger config */
    adc_external_trigger_config(ADC_INSERTED_CHANNEL, DISABLE);
    /* disable ADC interface */
    adc_disable();

    /* ADC interrupt config */
    adc_interrupt_disable(ADC_INT_EOIC);

    /* 16 times sample, 4 bits shift */
    adc_oversample_mode_config(ADC_OVERSAMPLING_ALL_CONVERT, ADC_OVERSAMPLING_SHIFT_3B, ADC_OVERSAMPLING_RATIO_MUL8);
    adc_oversample_mode_enable();
}



/**
    \brief      configure the TIMER peripheral
    \param[in]  none
    \param[out] none
    \retval     none
  */
void timer_config(void)
{
    timer_oc_parameter_struct timer_ocinitpara;
    timer_parameter_struct timer_initpara;
    timer_break_parameter_struct timer_breakpara;
    
    timer_deinit(TIMER0);
    /* initialize TIMER init parameter struct */
    timer_struct_para_init(&timer_initpara);
    /* TIMER0 configuration */
    timer_initpara.prescaler         = 0;
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;
    timer_initpara.period            = PWM_CYCLE;
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;
    timer_initpara.repetitioncounter = 0;
    timer_init(TIMER0, &timer_initpara);

    /* initialize TIMER channel output parameter struct */
    timer_channel_output_struct_para_init(&timer_ocinitpara);
    /*CH1 and CH2 configuration in PWM mode */
    timer_ocinitpara.outputstate  = TIMER_CCX_ENABLE;
    timer_ocinitpara.ocpolarity   = TIMER_OC_POLARITY_HIGH;
    timer_ocinitpara.ocidlestate  = TIMER_OC_IDLE_STATE_LOW;
    timer_channel_output_config(TIMER0, TIMER_CH_0, &timer_ocinitpara);

    /* configure TIMER channel 0 output pulse value */
    timer_channel_output_pulse_value_config(TIMER0, TIMER_CH_0, g16pwm_duty);
    /* configure TIMER channel 0 PWM0  mode */
    timer_channel_output_mode_config(TIMER0, TIMER_CH_0, TIMER_OC_MODE_PWM0);
    /* enable TIMER channel output shadow function */
    timer_channel_output_shadow_config(TIMER0, TIMER_CH_0, TIMER_OC_SHADOW_ENABLE);



    timer_ocinitpara.outputstate  = TIMER_CCX_ENABLE;
    timer_ocinitpara.ocpolarity   = TIMER_OC_POLARITY_HIGH;
    timer_ocinitpara.ocidlestate  = TIMER_OC_IDLE_STATE_LOW;
    timer_channel_output_config(TIMER0, TIMER_CH_3, &timer_ocinitpara);

    /* configure TIMER channel 0 output pulse value */
    timer_channel_output_pulse_value_config(TIMER0, TIMER_CH_3, g16pwm_duty+10);
    /* configure TIMER channel 3 PWM1  mode */
    timer_channel_output_mode_config(TIMER0, TIMER_CH_3, TIMER_OC_MODE_PWM1);
    /* enable TIMER channel output shadow function */
    timer_channel_output_shadow_config(TIMER0, TIMER_CH_3, TIMER_OC_SHADOW_ENABLE);

    /* enable TIMER primary output function */
    timer_primary_output_config(TIMER0, DISABLE);
    /* auto-reload preload enable */
    timer_auto_reload_shadow_enable(TIMER0);
}

/*!
    \brief      configure DMA interrupt
    \param[in]  none
    \param[out] none
    \retval     none
*/
void nvic_config(void)
{
    nvic_irq_enable(ADC_CMP_IRQn , 0);
    /* enable and set key EXTI interrupt to the specified priority */
    nvic_irq_enable(EXTI4_15_IRQn, 2);
}
/*!
    \brief      initialize the EXTI configuration of the key
    \param[in]  none
    \param[out] none
    \retval     none
*/

void key_exti_init(void)
{
    
    /* connect key EXTI line to key GPIO pin */
    syscfg_exti_line_config(EXTI_SOURCE_GPIOA, EXTI_SOURCE_PIN5);
    syscfg_exti_line_config(EXTI_SOURCE_GPIOA, EXTI_SOURCE_PIN6);
    /* configure key EXTI line */
    exti_init(EXTI_5, EXTI_INTERRUPT, EXTI_TRIG_FALLING);
    exti_interrupt_flag_clear(EXTI_5);
    exti_init(EXTI_6, EXTI_INTERRUPT, EXTI_TRIG_FALLING);
    exti_interrupt_flag_clear(EXTI_6);
}

void Init_global_variable(void)
{
    uint16_t m16index;
    flag_run_time = 0;
    pid_vout_calc_enable_flag = 0;
    pid_current_calc_enable_flag = 0;
    err_flag = 0;
    vout_current_value = 0;
    calvin_step = 0;
    gf32Vout_value = 0.0f;
    g8trigCurrentPID = 0;
    g8trigOVP = 0;
    g8Vin_enable = 0;
    gf32Vin_offset = 0.0f;
    g8Vin_add_pid = 0;
    k = 30.0f;
    m = 1;
    g16delay = 0;
    gf32current_para = 3.3f/(4095.0f*11.0f);
    gf32vin_para = 3.3f/4095.0f;
    gf32vout_para = 3.3f*541.6f/(4095.0f*3.6f);
    pfc_samp.CURRENT = 0.0f;
    pfc_samp.VAC = 0.0f;
    pfc_samp.VOUT = 0.0f;
    pfc_samp.VAC_MAX = 0.0f;
    pfc_samp.VAC_MIN = 0.0f;
    pfc_duty_foreback = 0;
    pfc_kk = 20;
    pfc_m = 1.0f;
    gf32VAC = 1.65f;
    current_ref = 0;
    voltage_ref = 415.0f;
    soft_start_cout = 0;
    soft_duty_cout = 0;
    g8sample_init_over = 0;
    g16Vout_OVP = (uint16_t)(voltage_ref + 50.0f)*(4095.0f*3.6f)/ (3.3f*543.6f);
    g16Vout_OCP = (uint16_t)(8.0f*(4095.0f*11.0f)/(3.3f * 20.0f));
    gf32Vin_max_bak = 1.65f;
    gf32Vin_min_bak = 1.65f;
    gf32Vin_max = 1.65f;
    gf32Vin_min = 1.65f;
    gf32Vin_average = 1.65f;
    g16pwm_duty = 10;
    pfc_duty = 0.0f;
    pfc_duty_record = 0.0f;
    g16temp_cnt = 0;
    soft_start_flag_2 = 0;
    soft_start_flag = 0;
    pfc_kg = 0;
    g16step_cnt = 0;
    g16sample_cnt = 0;
    Start_button_flag = 0;
    g16pwm_duty_para = 1.0f;
    g8temp_protect_flag = 0;
}

/*!
    \brief      main function
    \param[in]  none
    \param[out] none
    \retval     none
*/


int main(void)
{
    uint16_t index;
    /* configure systick */
    systick_config();
    /* configure the RCU */
    rcu_config();
    /* configure the GPIO ports */
    gpio_config();
    /* initialize the key */
    key_exti_init();
    /*initial global variable*/
    Init_global_variable();
    /* PID parameter configuration */
    pfc_pid_init();    
    /* configure interrupt */
    nvic_config();
    /* TIMER configuration */
    timer_config();
    /* ADC configuration */
    adc_config();
    //debug_init();
    g8PFCStatusFlag = PFC_START;
    while(1){
        switch(g8PFCStatusFlag)
        {
            case PFC_STOP:
                gpio_bit_reset(PFC_READY_PORT ,PFC_READY_PIN);
                /* disable a TIMER */
                timer_disable(TIMER0);
                adc_interrupt_disable(ADC_INT_EOIC);
                pfc_update_timer_duty(0.0f);
                /* enable TIMER primary output function */
                timer_primary_output_config(TIMER0, DISABLE);
                /*initial global variable*/
                Init_global_variable();
                pfc_pid_init(); 
                gpio_bit_reset(LED1_DEBUG_PORT, LED1_DEBUG_PIN);
                gpio_bit_reset(LED2_DEBUG_PORT, LED2_DEBUG_PIN);
                break;
            case PFC_START:
                g8PFCStatusFlag = PFC_RUN;
                gpio_bit_set(LED1_DEBUG_PORT, LED1_DEBUG_PIN);
                gpio_bit_set(LED2_DEBUG_PORT, LED2_DEBUG_PIN);
                #if 1
                /* ADC external trigger config */
                adc_external_trigger_config(ADC_INSERTED_CHANNEL, ENABLE);
                /* enable ADC interface */
                adc_enable();
                delay_1ms(1U);
                /* ADC calibration and reset calibration */
                adc_calibration_enable();
                /* enable TIMER primary output function */
                timer_primary_output_config(TIMER0, ENABLE);
                /* enable a TIMER */
                timer_enable(TIMER0);
                /* enable adc interrupt */
                adc_interrupt_enable(ADC_INT_EOIC);
                gpio_bit_reset(BUZZER_PORT,BUZZER_PIN);
                #endif
                break;
            case PFC_RUN:
                break;
            case PFC_UPDATE_PWM:
                g8PFCStatusFlag = PFC_RUN;
                break;
            case PFC_PRINT_OK:
                g8PFCStatusFlag = PFC_RUN;
                break;
            case PFC_PRINT_ERR:
                g8PFCStatusFlag = PFC_STOP;
                break;
            case PFC_IDLE:
                break;
            default:
                break;
        }
    }
}

/* retarget the C library printf function to the USART */
int fputc(int ch, FILE *f)
{
    usart_data_transmit(EVAL_COM, (uint8_t)ch);
    while(RESET == usart_flag_get(EVAL_COM, USART_FLAG_TBE));

    return ch;
}
