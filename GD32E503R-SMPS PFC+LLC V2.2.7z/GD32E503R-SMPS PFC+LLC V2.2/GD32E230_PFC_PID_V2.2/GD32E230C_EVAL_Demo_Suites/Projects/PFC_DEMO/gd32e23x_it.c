/*!
    \file    gd32e23x_it.c
    \brief   interrupt service routines
    
    \version 2019-02-19, V1.0.0, firmware for GD32E23x
    \version 2020-12-12, V1.1.0, firmware for GD32E23x
*/

/*
    Copyright (c) 2020, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "gd32e23x_it.h"
#include "systick.h"
#include "main.h"
#include "pid.h"

mc_usart_debug debug_data;



/*!
    \brief      this function handles NMI exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void NMI_Handler(void)
{
}

/*!
    \brief      this function handles HardFault exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void HardFault_Handler(void)
{
    /* if Hard Fault exception occurs, go to infinite loop */
    while(1){
    }
}

/*!
    \brief      this function handles SVC exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void SVC_Handler(void)
{
}

/*!
    \brief      this function handles PendSV exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void PendSV_Handler(void)
{
}

/*!
    \brief      this function handles SysTick exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void SysTick_Handler(void)
{
    delay_decrement();
}



/*!
    \brief      this function handles external lines 4 to 15 interrupt request
    \param[in]  none
    \param[out] none
    \retval     none
*/
void EXTI4_15_IRQHandler(void)
{
    exti_interrupt_flag_clear(EXTI_6);
    exti_interrupt_flag_clear(EXTI_5);
    if(0 == Start_button_flag)
    {
        Start_button_flag = 1;
        #if 0
        gpio_bit_write(LED1_DEBUG_PORT, LED1_DEBUG_PIN,(bit_status)(1-gpio_input_bit_get(LED1_DEBUG_PORT, LED1_DEBUG_PIN)));
        #endif
        if(g8PFCStatusFlag == PFC_STOP)
        {
            g8PFCStatusFlag = PFC_START;
        }
    }
    gpio_bit_reset(BUZZER_PORT,BUZZER_PIN);
}


void ADC_CMP_IRQHandler(void)
{
    uint8_t m8sample_cnt = 0;
    m8sample_cnt = (uint8_t)(g16sample_cnt % 3);
    /* clear the interrupt flag */
    adc_interrupt_flag_clear(ADC_INT_EOIC);
    /* 3-shunt current sampling */
    current_voltage_read_sample();
    calculate_duty_para();
    if((pfc_samp.VOUT >= (voltage_ref + 50.0f))||(g16current_value >= g16Vout_OCP))
    {
        g8PFCStatusFlag = PFC_STOP;
        timer_disable(TIMER0);
        adc_interrupt_disable(ADC_INT_EOIC);
        pfc_update_timer_duty(0.0f);
        /* enable TIMER primary output function */
        timer_primary_output_config(TIMER0, DISABLE);
        g8trigOVP = 1;
        gpio_bit_set(BUZZER_PORT,BUZZER_PIN);
        return;
    }
    g16step_cnt++;
    if(g16step_cnt >= 4096)
    {
        g16step_cnt = 0;
        g8sample_init_over = 1;
        calculate_vin_parameter(1);
        if(soft_start_flag_2 == 1)
        {
            if(SET == gpio_input_bit_get(PFC_RES_PORT, PFC_RES_PIN))
            {
                g8temp_protect_flag += 1;
                if(g8temp_protect_flag >= 100)
                {
                    g8PFCStatusFlag = PFC_STOP;
                    timer_disable(TIMER0);
                    adc_interrupt_disable(ADC_INT_EOIC);
                    pfc_update_timer_duty(0.0f);
                    /* enable TIMER primary output function */
                    timer_primary_output_config(TIMER0, DISABLE);
                    gpio_bit_set(BUZZER_PORT,BUZZER_PIN);
                    return;
                }
            }
            else
            {
                g8temp_protect_flag = 0;
            }
        }
    }
    if(g8sample_init_over == 1)
    {
    if(soft_start_flag == 1){
        g16sample_cnt ++;
        if(g16sample_cnt >= 60)
        {
        #if 1
        if((pfc_samp.VOUT > voltage_ref)&&(soft_start_flag_2 == 0))
        {
            pfc_voltage.kp = 0.002f;
            pfc_current.kp_div = 0.25f;
            pfc_voltage.kp_div = 0.025f;
            pfc_voltage.ki_div = pfc_voltage.ki_div + 100;
            pfc_current.ki_div = pfc_current.ki_div+1000;
            pfc_kg = pfc_kg + 60;
            if(pfc_voltage.ki_div >= 10000)
            {
                pfc_voltage.ki_div = 10000;
                soft_start_flag_2 = 1;
                gpio_bit_set(PFC_READY_PORT ,PFC_READY_PIN);
            }
            if(pfc_current.ki_div >= 100000)
            {
                pfc_current.ki_div = 100000;
            }
            if(pfc_kg >= 6000)
            {
                pfc_kg = 6000;
            }
            pfc_current.ki_sum_upper_limit = pfc_current.upper_limit * pfc_current.ki_div;
            pfc_current.ki_sum_lower_limit = pfc_current.lower_limit * pfc_current.ki_div;
            pfc_voltage.ki_sum_upper_limit = pfc_current.upper_limit * pfc_current.ki_div;
            pfc_voltage.ki_sum_lower_limit = pfc_current.lower_limit * pfc_current.ki_div;	
        }
        #endif
        if(current_ref <= 0.8f)
        {
            pfc_voltage.kp = 0.0032f;
        }
        else
        {
            pfc_voltage.kp = 0.0008f;
        }
        g16sample_cnt = 0;
        current_ref = pid_regulation_float(voltage_ref,pfc_samp.VOUT,&pfc_voltage);
        //current_ref_temp = current_ref;
        g8trigCurrentPID = 1;
        }
        if(g8trigCurrentPID == 1)
        {
            pfc_kk = pfc_kg*current_ref/pfc_samp.VOUT;
            pfc_duty_foreback = pfc_kk*(1.0f - (pfc_m*(pfc_samp.VAC/pfc_samp.VOUT)));
            current_ref_temp = current_ref*pfc_samp.VAC/pfc_samp.VOUT;
            pfc_duty = pid_regulation_float(current_ref_temp,pfc_samp.CURRENT ,&pfc_current);
            pfc_duty_record_TEMP = pfc_duty;
            pfc_duty = pfc_duty_foreback+pfc_duty;
            #if 1
            if(gf32Vin_max_bak < 2.3f)
            {
                g8PFCStatusFlag = PFC_STOP;
                timer_disable(TIMER0);
                adc_interrupt_disable(ADC_INT_EOIC);
                pfc_update_timer_duty(0.0f);
                /* enable TIMER primary output function */
                timer_primary_output_config(TIMER0, DISABLE);
            }
            #endif
            if(pfc_duty > 50){
                pfc_duty = 50;
            }
            pfc_duty = pfc_duty*g16pwm_duty_para;
        }
    }else{
    #if 1
    if(pfc_samp.VOUT < 0.5f*voltage_ref)
    {
        g8PFCStatusFlag = PFC_STOP;
        timer_disable(TIMER0);
        adc_interrupt_disable(ADC_INT_EOIC);
        pfc_update_timer_duty(0.0f);
        /* enable TIMER primary output function */
        timer_primary_output_config(TIMER0, DISABLE);
    }
    #endif
    if(pfc_samp.VOUT > (0.9f*voltage_ref)){
        soft_start_cout++;
    }else{
        soft_duty_cout++;
        if(soft_duty_cout == 500){
            pfc_duty += 0.1f;
            soft_duty_cout = 0;
        }
        if(pfc_duty > 30.0f){
            pfc_duty = 30.0f;
        }
    }
    if(soft_start_cout == 10){
        soft_start_flag = 1;
        soft_start_cout = 0;
        soft_duty_cout = 0;
    }
        pfc_duty_record = pfc_duty;
    }
    pfc_duty_record = pfc_duty;
    pfc_update_timer_duty(pfc_duty);
    }
    calculate_vin_parameter(0);
    #if 0
    #ifdef USART_DEBUG
        debug_data.data1 =(uint16_t)(pfc_duty_record_TEMP*10) ;//duty_set;//TIMER_CH3CV(TIMER2);//current_reference;//speed_count_temp/10;//speed_rmin;
        debug_data.data2 = (uint16_t)(pfc_duty_foreback*100);;//pfc_samp.VAC;
        debug_data.data3 = (uint16_t)(pfc_samp.CURRENT*100);;//(pfc_samp.CURRENT*100);//duty_set;//speed_rmin;//duty_set;//stop_flag*10;
        debug_data.data4 = (uint16_t)(current_ref*100);;//pfc_samp.VAC;
        ebug_usart_data_transfer(debug_data);
    #endif
    #endif
}


