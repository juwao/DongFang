/*!
    \file    pid.c
    \brief   pid controller configure file

    \version 2020-06-30, V1.0.0, demo for GD32E50x
*/

/*
    Copyright (c) 2019, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "pid.h"
#include "main.h"
#include "gd32e23x.h"
//#include <stdio.h>

float32 reference_vout;
float32 bak_reference_vout;
float32 last_reference_vout;
float32 error_reference_vout;
float32 vout_current_value;
uint8_t err_flag, calvin_step, soft_start_flag,soft_start_flag_2;

unsigned char skip_pid_calculate;
unsigned char flag_change_pid_para;
pid_parameter_float pfc_current;
pid_parameter_float pfc_voltage;
PFC_adc_sample pfc_samp;

#ifdef SWITCH_MODE_ENABLE
PID_TypeDef pid_voltage_loop_2;
#endif

float32 pid_result, gf32current_para,gf32vout_para,gf32vin_para;
float32 pfc_duty,pfc_duty_foreback,pfc_kk,pfc_m,gf32VAC,pfc_duty_record,pfc_duty_record_TEMP;
float32 current_ref,voltage_ref,current_ref_temp;
uint16_t soft_start_cout,soft_duty_cout;
uint16_t g16current_value;
float32 gf32current_temp;
uint32_t pfc_kg;

void pfc_pid_init(void){

    pfc_current.kp = 0.25f;
    pfc_current.kp_div = 0.05f;
    pfc_current.ki = 1000;
    pfc_current.ki_div = 1000;
    pfc_current.ki_sum = 3000000;
    pfc_current.upper_limit = 30.0f;
    pfc_current.lower_limit = 0.0f;
    pfc_current.error  = 0;
    pfc_current.output = 0;
    pfc_current.ki_sum_upper_limit = pfc_current.upper_limit * pfc_current.ki_div;
    pfc_current.ki_sum_lower_limit = pfc_current.lower_limit * pfc_current.ki_div;
    pfc_current.direction_flag = 0;

    pfc_voltage.kp = 0.002f;
    pfc_voltage.kp_div = 0.005f;
    pfc_voltage.ki = 100;
    pfc_voltage.ki_div = 100;
    pfc_voltage.ki_sum = 4000000;
    pfc_voltage.upper_limit = 3.0f;
    pfc_voltage.lower_limit = 0.0f;
    pfc_voltage.error  = 0;
    pfc_voltage.output = 0;
    pfc_voltage.ki_sum_upper_limit = pfc_voltage.upper_limit * pfc_voltage.ki_div;
    pfc_voltage.ki_sum_lower_limit = pfc_voltage.lower_limit * pfc_voltage.ki_div;
    pfc_voltage.direction_flag = 0;
}

float32 pid_regulation_float(float ref, float now, pid_parameter_float *pid_para)
{
    float output_temp = 0;

    /* calculate the error */
    pid_para->error = (ref - now);
    pid_para->i_index = 1;
    pid_para->ki_sum += pid_para->error * pid_para->ki;

    /* integration anti-windup */
    if(pid_para->ki_sum > pid_para->ki_sum_upper_limit){
        pid_para->ki_sum = pid_para->ki_sum_upper_limit;
    }else if(pid_para->ki_sum < pid_para->ki_sum_lower_limit){
        pid_para->ki_sum = pid_para->ki_sum_lower_limit;
    }

    output_temp = pid_para->error * pid_para->kp / pid_para->kp_div + pid_para->i_index*pid_para->ki_sum / pid_para->ki_div;

    /* output anti-windup */
    if(output_temp < pid_para->lower_limit){
        output_temp = pid_para->lower_limit;
    }else if(output_temp > pid_para->upper_limit){
        output_temp = pid_para->upper_limit;
    }

    if(pid_para->direction_flag){
    #if 0
        if(DIRECTION_CW == direction){
            output_temp = -output_temp;
        }
    #endif
    }
    
    pid_para->output = output_temp;

    return (pid_para->output);
}

void pfc_update_timer_duty(float32 mf32pfc_duty)
{
    g16pwm_duty = (uint16_t)(PWM_CYCLE * mf32pfc_duty * 0.01f);	
    timer_channel_output_pulse_value_config(TIMER0, TIMER_CH_0, g16pwm_duty);
    timer_channel_output_pulse_value_config(TIMER0, TIMER_CH_3, g16pwm_duty+50);
}

void current_voltage_read_sample(void)
{
    uint16_t m16current_value, m16vin_value,m16vout_value;
    float32 mf32VAC;
    g16current_value = adc_inserted_data_read(ADC_INSERTED_CHANNEL_0);
    m16vin_value = adc_inserted_data_read(ADC_INSERTED_CHANNEL_1);
    m16vout_value = adc_inserted_data_read(ADC_INSERTED_CHANNEL_2);

    pfc_samp.CURRENT = (float32)g16current_value* gf32current_para*20.0f;//3.3f/(4095.0f*11.0f);
    gf32VAC = (float32)m16vin_value *3.3f/4095.0f;
    if(gf32VAC >= gf32Vin_average)
    {
        pfc_samp.VAC = (gf32VAC-gf32Vin_average)*282.0f;
    }
    else
    {
        pfc_samp.VAC = (gf32Vin_average-gf32VAC)*282.0f;
    }
    if(pfc_samp.VAC > pfc_samp.VAC_MAX)
    {
        pfc_samp.VAC_MAX = pfc_samp.VAC;
    }
    pfc_samp.VOUT = (float32)m16vout_value*gf32vout_para;	
}

void calculate_vin_parameter(uint8_t m8state)
{
    if(m8state == 1)
    {
        gf32Vin_max_bak = gf32Vin_max;
        gf32Vin_min_bak = gf32Vin_min;

        gf32Vin_offset = (gf32Vin_max_bak - gf32Vin_min_bak)/2;
        gf32Vin_average = (gf32Vin_max_bak + gf32Vin_min_bak)/2;

        gf32Vin_max = 1.65f;
        gf32Vin_min = 1.65f;
    }
    if(gf32Vin_max < gf32VAC)
    {
        gf32Vin_max = gf32VAC;
    }
    if(gf32Vin_min > gf32VAC)
    {
        gf32Vin_min = gf32VAC;
    }
}

void calculate_duty_para(void)
{
    g16pwm_duty_para = 1.0f;
    if(pfc_samp.VOUT > (voltage_ref + 40.0f))
    {
        g16pwm_duty_para = 0.01f;
    }
    else if(pfc_samp.VOUT > (voltage_ref + 30.0f))
    {
        g16pwm_duty_para = 0.3f;
    }
    else if(pfc_samp.VOUT > (voltage_ref + 20.0f))
    {
        g16pwm_duty_para = 0.5f;
    }
    else if(pfc_samp.VOUT > (voltage_ref + 10.0f))
    {
        g16pwm_duty_para = 0.7f;
    }
}

