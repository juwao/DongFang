/*!
    \file    main.h
    \brief   the header file of main
    
    \version 2019-02-19, V1.0.0, firmware for GD32E23x
    \version 2020-12-12, V1.1.0, firmware for GD32E23x
*/

/*
    Copyright (c) 2020, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#ifndef MAIN_H
#define MAIN_H
#include "pid.h"
#include <stdio.h>
#include "gd32e23x.h"
#include "gd32e23x_it.h"

/* PFC driver pin configuration */
#define PFC_DRIVER_PORT                         GPIOA
#define PFC_DRIVER_PIN                          GPIO_PIN_8

/* BUTTON pin configuration */
#define K2_BUTTON_PORT                          GPIOA
#define K2_BUTTON_PIN                           GPIO_PIN_5
#define K3_BUTTON_PORT							GPIOA
#define K3_BUTTON_PIN							GPIO_PIN_6

/* LED pin configuration */
#define LED1_DEBUG_PORT							GPIOB
#define LED1_DEBUG_PIN							GPIO_PIN_9
#define LED2_DEBUG_PORT							GPIOB
#define LED2_DEBUG_PIN							GPIO_PIN_8

/* BUZZER pin configuration */
#define BUZZER_PORT								GPIOC
#define BUZZER_PIN								GPIO_PIN_13

/* FAN pin configuration */
#define FAN_PORT								GPIOB
#define FAN_PIN									GPIO_PIN_10

/* ADC pin configuration */
#define PFC_VS_PORT								GPIOA
#define PFC_VS_PIN								GPIO_PIN_0
#define PFC_CS2_PORT							GPIOA
#define PFC_CS2_PIN								GPIO_PIN_1
#define VAC_PFC_SENSE2_PORT						GPIOA
#define VAC_PFC_SENSE2_PIN						GPIO_PIN_3

/* PFC-LLC communication pin configuration */
#define PFC_READY_PORT							GPIOA
#define PFC_READY_PIN							GPIO_PIN_12
#define PFC_RES_PORT							GPIOA
#define PFC_RES_PIN								GPIO_PIN_11
#define PFC_TX1_PORT							GPIOA
#define PFC_TX1_PIN								GPIO_PIN_9


#define PWM_CYCLE           1200
#define VIN_SAMPLE_LENGTH   60
#define VOUT_SAMPLE_LENGTH  1
#define MAX_FREGUENCE_STEP  25
#define MIN_FREQUENCE_STEP  15
#define SAMPLE_AVERAGE_LENGTH		3
#define TEST_LENGTH			400

#define PFC_STOP            0x00
#define PFC_START           0x01
#define PFC_RUN             0x02
#define PFC_UPDATE_PWM      0x03
#define PFC_PRINT_OK        0x04
#define PFC_PRINT_ERR       0x05
#define PFC_IDLE            0x06   


/* debug function */
/* debug buffer size configuration, 12 bytes per frame */
#define DEBUG_BUFFER_SIZE                   (600U)
/* usart configuration */
#define USART_DEBUG_ENABLE
#define USART_BPS                           (460800U)                           /* the baudrate of the usart */
#define DEBUG_USART                         USART0
#define DEBUG_USART_CLOCK                   RCU_USART0
#define USART_RX_PORT                       GPIOB
#define USART_RX_PIN                        GPIO_PIN_7
#define USART_TX_PORT                       GPIOB
#define USART_TX_PIN                        GPIO_PIN_6

/* USART debug */
#define USART_DEBUG



extern uint8_t  g8PFCStatusFlag;
extern uint16_t g16pwm_duty,g16pwm_test;
extern uint16_t flag_run_time;

extern uint8_t	pid_vout_calc_enable_flag, pid_current_calc_enable_flag;
extern uint16_t Vout_value,g16sample_cnt,g16Vout_OVP,g16Vout_OCP;
extern uint8_t  g8Vin_enable,g8Vin_add_pid;
extern uint8_t  Start_button_flag;
extern float32  gf32Vout_value,actual_current_temp;
extern float32  gf32Vin_max_bak, gf32Vin_min_bak,gf32Vin_offset,gf32Vin_average,gf32Vin_max,gf32Vin_min;
extern uint8_t  check_vin_parameter_enable;
extern uint8_t  g8trigCurrentPID,g8trigOVP,g8sample_init_over;
extern uint16_t g16step_cnt,g16temp_cnt,g16delay;
extern float32 actual_current,actual_vin,actual_vin_average,actual_vin_offset;
extern float32 k,m,g16pwm_duty_para;
extern uint8_t  g8temp_protect_flag;
#endif /* MAIN_H */
