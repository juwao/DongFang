
/*
    Copyright (c) 2019, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#ifndef PID_H
#define PID_H
#include <stdio.h>
//#define OPEN_LOOP_CTRL
#define VOLTAGE_SINGLE_CLOSED_LOOP_CTRL
#define CURRENT_VOLTAGE_CLOSED_LOOP_CTRL

#define TYPE_REF_VOLT_UP    1
#define TYPE_REF_VOLT_DOWN  0

#ifdef VOLTAGE_SINGLE_CLOSED_LOOP_CTRL
#define REF_VOLT_ENABLE_GAP 8
#endif
#if 0
#ifdef CURRENT_VOLTAGE_CLOSED_LOOP_CTRL
    #define REF_VOLT_ENABLE_GAP 4
    #define VOLT_SWITCH_MODE     5
    #define SWITCH_MODE_ENABLE
#endif
#endif
#define PID_PARA_NUM        ((uint8_t)2U) 
//#define LCD_BRIGHTNESS_ADJUSTABLE

#define AVERAGE_VOUT_DISPLAY 
#define VIN_HISTORY_DATA_NUM  ((uint8_t)4U)

#define AVERAGE_ISENSE_DISPLAY 
#define ISENSE_HISTORY_DATA_NUM  ((uint8_t)10U)

typedef    float    float32;
typedef    double   float64;

typedef unsigned          char uint8_t;
typedef unsigned short     int uint16_t;
typedef unsigned           int uint32_t;

typedef struct _PID{
float32 SetPoint; //����:����ֵ
float32 Feedback; //����:����ֵ
float32 T; //����ʱ��
float32 Kp; //��������
float32 Ti;//����ʱ��
float32 Td;//΢��ʱ��
float32 A;//ϵ��1:A = Kp(1 + T/Ti + Td/T);
float32 B;//ϵ��2: B = Kp(1 + 2Td/T)
float32 C;//ϵ��3:C = Kp*Td/T
float32 ek;//��ǰ���
float32 ek_1;//ǰһ�����
float32 ek_2;//��һ�����
float32 output;//���ֵ
float32 last_output;//��һ�����ֵ
float32 increment;//����ֵ
float32 outmax;//����������ֵ
float32 outmin;//���������Сֵ
} PID_TypeDef;


/* the structure of pid parameter */
typedef struct{
    float32 kp;                                                                /* the proportional factor */
    float32 kp_div;                                                            /* the proportional division factor */
    float32 ki;                                                                   /* the integral factor */
    float32 ki_div;                                                            /* the integral division factor */
    uint8_t i_index;                                                            /* the integral separation index */
    float32 ki_sum;                                                               /* the sum of the integral term */
    float32 ki_sum_upper_limit;                                                 /* the upper limit of integral term */
    float32 ki_sum_lower_limit;                                                 /* the lower limit of integral term */
    float32 upper_limit;                                                        /* the upper limit of ouput */
    float32 lower_limit;                                                        /* the lower limit of ouput */
    float32 error;                                                              /* the error of the input */
    float32 output;                                                             /* the output varialbe */
    uint8_t direction_flag;                                                     /* the sign of the output variable */
}pid_parameter_float;

typedef struct _PID_Para{
float32 para_A;
float32 para_B;
float32 para_C;
} PID_Para;


typedef struct{
	float32 VAC;
	float32 CURRENT;
	float32 VOUT;
	float32 VAC_MAX;
	float32 VAC_MIN;
}PFC_adc_sample;

extern float32 reference_vout;
extern float32 bak_reference_vout;
extern float32 last_reference_vout;
extern float32 error_reference_vout;
extern float32 vout_current_value;
extern uint8_t err_flag,calvin_step,soft_start_flag,soft_start_flag_2;
extern unsigned char skip_pid_calculate;
extern unsigned char flag_change_pid_para;
extern pid_parameter_float pfc_current;
extern pid_parameter_float pfc_voltage;
extern PFC_adc_sample pfc_samp;
#ifdef SWITCH_MODE_ENABLE
extern PID_TypeDef pid_voltage_loop_2;
#endif

extern float32 pid_result,gf32current_para,gf32vout_para,gf32vin_para;

extern float32 pfc_duty,pfc_duty_foreback,pfc_kk,pfc_m,gf32VAC,pfc_duty_record,pfc_duty_record_TEMP;
extern float32 current_ref,voltage_ref,current_ref_temp;
extern uint16_t soft_start_cout,soft_duty_cout;

extern uint16_t g16current_value;
extern float32 gf32current_temp;
extern uint32_t pfc_kg;

void pfc_update_timer_duty(float32 mf32pfc_duty);
float32 pid_regulation_float(float ref, float now, pid_parameter_float *pid_para);
void current_voltage_read_sample(void);
void pfc_pid_init(void);
void calculate_vin_parameter(uint8_t m8state);
void calculate_duty_para(void);
#endif /* PID_H */