/*!
    \file    main.c
    \brief   EXMC LCD demo

    \version 2020-06-30, V1.0.0, demo for GD32E50x
*/

/*
    Copyright (c) 2020, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "gd32e50x.h"
#include <stdio.h>
#include "gd32e503z_eval.h"
#include "systick.h"
#include <stdio.h>
#include "delay.h"
#include "main.h"
#include "pid.h"
#include "debug.h"

uint8_t g8cmd;
uint32_t g32prevent_shake;
uint8_t g8shake_flag;

static void rcu_config(void);
static void nvic_config(void);
static void gpio_config(void);


/*!
    \brief      main function
    \param[in]  none
    \param[out] none
    \retval     none
*/
int main(void)
{
    uint8_t m8cmd = 0;
    uint8_t index, test = 0;
    /* configure systick */
    systick_config();
	/* delay init*/
    delay_init(180);
    delay_ms(500);
    /* configure the RCU */
    rcu_config();
    /* configure the GPIO ports */
    gpio_config();
    /* PID parameter configuration */
    pfc_pid_init();  
    /* NVIC configuration */
    nvic_config();
	/*initilize the EXTI configuration of the key*/
	key_exti_init();
    /* configure the SHRTIMER peripheral */
    shrtimer_config();  
	/* Initial global variable*/
	Init_global_variable();
    /* ADC configuration */
    adc_config();
	g32prevent_shake = 0;
	g8powercheck = 0;
	//debug_init();
	g8cmd = LLC_DEFAULT_STATUS;//LLC_DEFAULT_STATUS;
    while (1){  
        switch(g8cmd)
        {
            case LLC_DEFAULT_STATUS:
				 LLC_UPDATE_Frequence(SHRTIMER_CAR);
                 /* enable output channel */
				 shrtimer_timers_counter_disable(SHRTIMER0, SHRTIMER_ST2_COUNTER);
                 shrtimer_output_channel_disable(SHRTIMER0, SHRTIMER_ST2_CH0);
                 shrtimer_output_channel_disable(SHRTIMER0, SHRTIMER_ST2_CH1);
                 Init_global_variable();
				 pfc_pid_init();
				 gpio_bit_reset(SR1_CTR_PORT,SR1_CTR_PIN);
				 gpio_bit_reset(SR2_CTR_PORT,SR2_CTR_PIN);
				 #if 1
				 if(SET == gpio_input_bit_get(LLC_READY_PORT, LLC_READY_PIN))
				 {
				 	g32prevent_shake ++;
					if(g32prevent_shake >= 100)
					{
				 		LLC_STATUS_Set(PFC_RIGHT_CONDITION);
						g32prevent_shake = 0;
					}
				 }
				 else
				 {
					g32prevent_shake = 0;
				 }
				 #endif
				 gpio_bit_reset(LED2_PORT,LED2_PIN);
				 gpio_bit_reset(LED1_PORT,LED1_PIN);
                 break;
            case PFC_RIGHT_CONDITION:
                 /* enable output channel */
                 shrtimer_output_channel_enable(SHRTIMER0, SHRTIMER_ST2_CH0);
                 shrtimer_output_channel_enable(SHRTIMER0, SHRTIMER_ST2_CH1);
				 gpio_bit_reset(LED2_PORT,LED2_PIN);
                 LLC_Soft_Start();
				 g8trigenable = 1;
				 LLC_STATUS_Set(LLC_RUN_STATUS);
				 gpio_bit_set(LED1_PORT,LED1_PIN);
                 break;
			case LLC_RUN_STATUS:
				
				 if(1 == pid_vout_calc_enable_flag)
				 {
				 	pid_vout_calc_enable_flag = 0;
				 	pid_vout_calc_enable();
				 	LLC_UPDATE_Frequence(g32carlvalue_last);
				 }
				 #if 1
				 	if(RESET == gpio_input_bit_get(LLC_READY_PORT, LLC_READY_PIN))
				 	{
				 		g32prevent_shake ++;
						if(g32prevent_shake >= 10000)
						{
				 			LLC_STATUS_Set(PFC_FAULT_CONDITION);
							g32prevent_shake = 0;
						}
				 	}
					else
					{
						g32prevent_shake = 0;
					}
				 	#endif
				 break;
			case PFC_FAULT_CONDITION:
				 LLC_UPDATE_Frequence(SHRTIMER_CAR);
				 #if 1
				 if(SET == gpio_input_bit_get(LLC_READY_PORT, LLC_READY_PIN))
				 {
				 	g32prevent_shake ++;
					if(g32prevent_shake >= 10000)
					{
				 		LLC_STATUS_Set(PFC_RIGHT_CONDITION);
						g32prevent_shake = 0;
					}
				 }
				 else
				 {
					g32prevent_shake = 0;
				 }
				 #endif
				 break;
			default:
				 break;
        }
    }
}

/*!
    \brief     LLC_UPDATE_FREQUENCE
    \param[in]  m8status
    \param[out] none
    \retval     none
*/
void LLC_UPDATE_Frequence (uint32_t m32carlvalue_last)
{
	shrtimer_comparecfg_parameter_struct comparecfg_para;//??Slave_TIMER???????
	uint32_t m32carlvalue;
	m32carlvalue = m32carlvalue_last;
	#if 1
    shrtimer_timers_autoreload_value_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2,m32carlvalue );	
	/* configures the compare unit of a Slave_TIMER2 which work in waveform mode */
    comparecfg_para.compare_value = m32carlvalue_last/2;//??????,???:3?tSHRTIMER_CK??,???:0xFFFF - (1?tSHRTIMER_CK)
    shrtimer_slavetimer_waveform_compare_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, SHRTIMER_COMPARE0, &comparecfg_para);////??Slave_TIMER???????
	#if 1
	/* configures the compare unit of a Slave_TIMER2 which work in waveform mode */
    comparecfg_para.compare_value = (uint32_t)((float32)m32carlvalue_last*998.0f/1000.0f);//??????,???:3?tSHRTIMER_CK??,???:0xFFFF - (1?tSHRTIMER_CK)
	SHRTIMER_STXCMP1V(SHRTIMER0, SHRTIMER_SLAVE_TIMER2) = comparecfg_para.compare_value;

	comparecfg_para.compare_value = (uint32_t)((float32)m32carlvalue_last*485.7f/1000.0f);//??????,???:3?tSHRTIMER_CK??,???:0xFFFF - (1?tSHRTIMER_CK)
	SHRTIMER_STXCMP2V(SHRTIMER0, SHRTIMER_SLAVE_TIMER2) = comparecfg_para.compare_value;

	comparecfg_para.compare_value = (uint32_t)((float32)m32carlvalue_last/8.0f);//??????,???:3?tSHRTIMER_CK??,???:0xFFFF - (1?tSHRTIMER_CK)
	SHRTIMER_STXCMP3V(SHRTIMER0, SHRTIMER_SLAVE_TIMER2) = comparecfg_para.compare_value;
	#endif
	#endif
}

/*!
    \brief     LLC_STATUS_Set
    \param[in]  m8status
    \param[out] none
    \retval     none
*/
void LLC_STATUS_Set(uint8_t m8status)
{
	g8cmd = m8status;
}

/*!
    \brief     LLC_Soft_Start
    \param[in]  none
    \param[out] none
    \retval     none
*/

void LLC_Soft_Start(void)
{
    shrtimer_comparecfg_parameter_struct comparecfg_para;//??Slave_TIMER???????
    shrtimer_timers_counter_enable(SHRTIMER0, SHRTIMER_ST2_COUNTER);
	g32carlvalue_last = SHRTIMER_CAR;
	pid_vout_enable = 1;
}




/*!
    \brief      RCU configuration
    \param[in]  none
    \param[out] none
    \retval     none
*/
static void rcu_config(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_GPIOB);
	rcu_periph_clock_enable(RCU_GPIOC);
    rcu_periph_clock_enable(RCU_AF);
    rcu_periph_clock_enable(RCU_SHRTIMER);
    rcu_shrtimer_clock_config(RCU_SHRTIMERSRC_CKSYS);
    rcu_periph_clock_enable(RCU_ADC0);
    rcu_periph_clock_enable(RCU_ADC1);
	//rcu_periph_clock_enable(RCU_ADC2);
	rcu_adc_clock_config(RCU_CKADC_CKAPB2_DIV6);
	/* enable the peripherals clock */
    //rcu_periph_clock_enable(RCU_TIMER2);
}

/*!
    \brief      NVIC configuration
    \param[in]  none
    \param[out] none
    \retval     none
*/
static void nvic_config(void)
{
    /* configure the NVIC Preemption Priority Bits */
    nvic_priority_group_set(NVIC_PRIGROUP_PRE2_SUB2);
    /* enable and set SHRTIMER2 interrupt priority */
	nvic_irq_enable(SHRTIMER_IRQ3_IRQn, 0U, 0U);
    nvic_irq_enable(ADC0_1_IRQn, 1, 0);
	nvic_irq_enable(EXTI5_9_IRQn, 1, 1U);
}

/*!
    \brief      configure the TIMER peripheral
    \param[in]  none
    \param[out] none
    \retval     none
*/
void timer_config(void)
{
    /* ----------------------------------------------------------------------------
    TIMER2 Configuration: 
    TIMER2CLK = SystemCoreClock/18000 = 10KHz, the period is 1s(10000/10000 = 1s).
    ---------------------------------------------------------------------------- */
    timer_oc_parameter_struct timer_ocinitpara;
    timer_parameter_struct timer_initpara;
    /* deinit a TIMER */
    timer_deinit(TIMER2);
    /* initialize TIMER init parameter struct */
    timer_struct_para_init(&timer_initpara);
    /* TIMER2 configuration */
    timer_initpara.prescaler         = 17999;
    timer_initpara.alignedmode       = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection  = TIMER_COUNTER_UP;
    timer_initpara.period            = 9999;
    timer_initpara.clockdivision     = TIMER_CKDIV_DIV1;
    timer_init(TIMER2, &timer_initpara);
  	/* enable a TIMER */
    timer_enable(TIMER2);
    
}


/*!
    \brief      initilize the EXTI configuration of the key
    \param[in]  none
    \param[out] none
    \retval     none
*/
static void key_exti_init(void)
{
    /* connect key EXTI line to key GPIO pin */
    gpio_exti_source_select(LLCKEY_EXTI_PORT_SOURCE, LLCKEY_EXTI_PIN_SOURCE);
    /* configure key EXTI line */
    exti_init(LLCKEY_EXTI_LINE, EXTI_INTERRUPT, EXTI_TRIG_FALLING);
    exti_interrupt_flag_clear(LLCKEY_EXTI_LINE);
}


/*!
    \brief      GPIO configuration
    \param[in]  none
    \param[out] none
    \retval     none
*/
static void gpio_config(void)
{
    /* configure SHRTimer pin, ST2CH0_O(PB12),ST2CH1_O(PB13) */
    gpio_afio_port_config(AFIO_PB12_SHRTIMER_CFG, ENABLE);
    gpio_afio_port_config(AFIO_PB13_SHRTIMER_CFG, ENABLE);
    gpio_init(HO_PWM_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,HO_PWM_PIN);
    gpio_init(LO_PWM_PORT,GPIO_MODE_AF_PP,GPIO_OSPEED_50MHZ,LO_PWM_PIN);
	/* configure PB14/15 pin as output */
	gpio_init(SR1_CTR_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, SR1_CTR_PIN);
	gpio_init(SR2_CTR_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, SR2_CTR_PIN);
	gpio_bit_reset(SR1_CTR_PORT,SR1_CTR_PIN);
	gpio_bit_reset(SR2_CTR_PORT,SR2_CTR_PIN);

    /* configure ADC pin, 24V output voltage sampling -- ADC_IN10(PC0) */
    gpio_init(VOUT_24V_PORT, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, VOUT_24V_PIN);
    /* configure ADC pin, PFC TEMP sampling -- ADC_IN11(PC1) */
    gpio_init(PFC_TEMP_PORT, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, PFC_TEMP_PIN);
	/* configure ADC pin, PFC TEMP sampling -- ADC_IN12(PC2) */
    gpio_init(LLC_TEMP1_PORT, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, LLC_TEMP1_PIN);
	/* configure ADC pin, PFC TEMP sampling -- ADC_IN13(PC3) */
    gpio_init(LLC_TEMP2_PORT, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, LLC_TEMP2_PIN);
	
	/* configure button pin as input */
	gpio_init(LLCKEY_BUTTON_PORT, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, LLCKEY_BUTTON_PIN);
	
    /* configure led pin as output */
	gpio_init(LED1_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, LED1_PIN);
	gpio_init(LED2_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, LED2_PIN);
	gpio_bit_reset(LED1_PORT,LED1_PIN);
	gpio_bit_reset(LED2_PORT,LED2_PIN);
	/* configure debug pin as output */
	gpio_init(LLC_READY_PORT, GPIO_MODE_IPD, GPIO_OSPEED_50MHZ, LLC_READY_PIN);
	gpio_init(LLC_RES_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, LLC_RES_PIN);
	gpio_bit_reset(LLC_RES_PORT,LLC_RES_PIN);
	gpio_init(DISCHARGE_PORT, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, DISCHARGE_PIN);
	gpio_bit_reset(DISCHARGE_PORT, DISCHARGE_PIN);
	
}




/**
    \brief      configure the SHRTIMER peripheral
    \param[in]  none
    \param[out] none
    \retval     none
  */
void shrtimer_config(void)
{
/* -----------------------------------------------------------------------
    fSHRTIMER_CK:180MHz, from CK_SYS
    waveform period: 22500/(180M/4)=500us
    ST2_CH1_O: set request at Slave_TIMER2 period event, reset request at Slave_TIMER2 compare 0 event
  ----------------------------------------------------------------------- */    
    shrtimer_baseinit_parameter_struct baseinit_para;//����Master_TIMER/Slave_TIMERʱ��
    shrtimer_timerinit_parameter_struct timerinit_para;//���ö�ʱ�����β���
    shrtimer_timercfg_parameter_struct timercfg_para;//����Slave_TIMER�Ĳ��β���
    shrtimer_comparecfg_parameter_struct comparecfg_para;//����Slave_TIMER���εıȽϹ���
    shrtimer_channel_outputcfg_parameter_struct outcfg_para;//����Slave_TIMER���ε�ͨ������
    shrtimer_deadtimecfg_parameter_struct deadtimecfg_para;//��������ʱ��
    shrtimer_adctrigcfg_parameter_struct triggercfg_para;//����ADC����Դ�͸���Դ
    shrtimer_adctrigcfg_parameter_struct adctrigcfg_para;
	
    /* periodic DLL calibration */
    shrtimer_dll_calibration_start(SHRTIMER0, SHRTIMER_CALIBRATION_ONCE);//���ú�����DLLУ׼
    while(RESET == shrtimer_common_flag_get(SHRTIMER0, SHRTIMER_FLAG_DLLCAL));//��ȡSHRTIMERͨ�ñ�־
    
    /* Slave_TIMER2 Slave_TIMER3 time base clock config  */
    shrtimer_baseinit_struct_para_init(&baseinit_para);
    baseinit_para.period = SHRTIMER_CAR;        //����ֵ����Сֵ��3��tSHRTIMER_CKʱ�ӣ����ֵ: 0xFFFF - (1��tSHRTIMER_CK)
    baseinit_para.prescaler = SHRTIMER_PRESCALER_MUL16;//Ԥ��Ƶֵ
    baseinit_para.repetitioncounter = 0;//�ظ�����ֵ��0x00~0xFF
    baseinit_para.counter_mode = SHRTIMER_COUNTER_MODE_CONTINOUS;//����������ģʽ
    shrtimer_timers_base_init(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, &baseinit_para);//��ʼ��Master_TIMER/Slave_TIMERʱ��
    
    /* initialize Slave_TIMER2 to work in waveform mode */
    shrtimer_timerinit_struct_para_init(&timerinit_para);
    timerinit_para.cnt_bunch = SHRTIMER_TIMERBUNCHNMODE_MAINTAINCLOCK;//ͻ��ģʽ�¼�����ʱ��ֹͣ������������
    timerinit_para.dac_trigger = SHRTIMER_DAC_TRIGGER_NONE;//DAC����Դ
    timerinit_para.half_mode = SHRTIMER_HALFMODE_DISABLED;//ʹ�ܻ���ܰ벨ģʽ
    timerinit_para.repetition_update = SHRTIMER_UPDATEONREPETITION_ENABLED;//�ظ��¼����������¼�
    timerinit_para.reset_sync = SHRTIMER_SYNCRESET_DISABLED;//ͬ�����븴λ������
    timerinit_para.shadow = SHRTIMER_SHADOW_ENABLED;//ʹ�ܻ��߽���Ӱ�ӼĴ���
    timerinit_para.start_sync = SHRTIMER_SYNISTART_DISABLED;//ͬ����������������
    timerinit_para.update_selection = SHRTIMER_MT_ST_UPDATE_SELECTION_INDEPENDENT;//�����¼�Դѡ��
    shrtimer_timers_waveform_init(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, &timerinit_para);//��ʱ�����γ�ʼ��
    
    /* configures the deadtime mode */
    shrtimer_deadtimercfg_struct_para_init(&deadtimecfg_para);
    deadtimecfg_para.prescaler = SHRTIMER_DEADTIME_PRESCALER_MUL16;//����ʱ�䷢����Ԥ��Ƶ
    deadtimecfg_para.rising_value = DEADTIME_RIS_VAL;         //50ns//������������ֵ��0x0000~0xFFFF
    deadtimecfg_para.rising_sign = SHRTIMER_DEADTIME_RISINGSIGN_POSITIVE;//������������ֵ����
    deadtimecfg_para.rising_protect = SHRTIMER_DEADTIME_RISING_PROTECT_DISABLE;//����������ֵֵ�ͷ��ű���
    deadtimecfg_para.risingsign_protect = SHRTIMER_DEADTIME_RISINGSIGN_PROTECT_DISABLE;//���������ط��ű���
    deadtimecfg_para.falling_value = DEADTIME_FAL_VAL;        //50ns//�����½�����ֵ��0x0000~0xFFFF
    deadtimecfg_para.falling_sign = SHRTIMER_DEADTIME_FALLINGSIGN_POSITIVE;//�����½�����ֵ����
    deadtimecfg_para.falling_protect = SHRTIMER_DEADTIME_FALLING_PROTECT_DISABLE;//�����½���ֵֵ�ͷ��ű���
    deadtimecfg_para.fallingsign_protect = SHRTIMER_DEADTIME_FALLINGSIGN_PROTECT_DISABLE;//�����½��ط��ű���
    shrtimer_slavetimer_deadtime_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, &deadtimecfg_para);//����Slave_TIMER������ʱ��

	/* configure the general behavior of a Slave_TIMER2 which work in waveform mode */
    shrtimer_timercfg_struct_para_init(&timercfg_para);
    timercfg_para.balanced_mode = SHRTIMER_STXBALANCEDMODE_DISABLED;//ʹ�ܻ��ֹ����ģʽ
    timercfg_para.cnt_reset = SHRTIMER_STXCNT_RESET_NONE;//��������λԴ
    timercfg_para.deadtime_enable = SHRTIMER_STXDEADTIME_ENABLED;//ʹ�ܻ������������
    timercfg_para.delayed_idle = SHRTIMER_STXDELAYED_IDLE_DISABLED;//��ʱ����ģʽ
    timercfg_para.fault_enable = SHRTIMER_STXFAULTENABLE_NONE;//ʹ�ܻ����Slave_TIMER��������ͨ��
    timercfg_para.fault_protect = SHRTIMER_STXFAULT_PROTECT_READWRITE;//ʹ�ܻ���ܹ��ϱ�������
    timercfg_para.reset_update = SHRTIMER_STXUPDATEONRESET_DISABLED;//��������λ���������¼�
    timercfg_para.update_source = SHRTIMER_STXUPDATETRIGGER_NONE;//�����¼���������ʱ�������¼�����
    shrtimer_slavetimer_waveform_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, &timercfg_para);//����Slave_TIMER�Ĳ���
    shrtimer_timers_update_event_enable(SHRTIMER0, SHRTIMER_SLAVE_TIMER2);//ʹ��Master_TIMER/Slave_TIMER�����¼�
    /* configures the compare unit of a Slave_TIMER2 which work in waveform mode */
    shrtimer_comparecfg_struct_para_init(&comparecfg_para);
    comparecfg_para.compare_value = SHRTIMER_CAR/2;//�ȽϼĴ���ֵ����Сֵ��3��tSHRTIMER_CKʱ�ӣ����ֵ��0xFFFF - (1��tSHRTIMER_CK)
    shrtimer_slavetimer_waveform_compare_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, SHRTIMER_COMPARE0, &comparecfg_para);////����Slave_TIMER���εıȽϹ���
	/* configures the compare unit of a Slave_TIMER2 which work in waveform mode */
    //comparecfg_para.compare_value = (uint32_t)((float32)SHRTIMER_CAR*988.0f/1000.0f);//�ȽϼĴ���ֵ����Сֵ��3��tSHRTIMER_CKʱ�ӣ����ֵ��0xFFFF - (1��tSHRTIMER_CK)
    comparecfg_para.compare_value = (uint32_t)((float32)SHRTIMER_CAR*998.0f/1000.0f);//�ȽϼĴ���ֵ����Сֵ��3��tSHRTIMER_CKʱ�ӣ����ֵ��0xFFFF - (1��tSHRTIMER_CK)

    //comparecfg_para.compare_value = (uint32_t)((float32)SHRTIMER_CAR*968.0f/1000.0f);//�ȽϼĴ���ֵ����Сֵ��3��tSHRTIMER_CKʱ�ӣ����ֵ��0xFFFF - (1��tSHRTIMER_CK)

	shrtimer_slavetimer_waveform_compare_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, SHRTIMER_COMPARE1, &comparecfg_para);////����Slave_TIMER���εıȽϹ���
	//comparecfg_para.compare_value = (uint32_t)((float32)SHRTIMER_CAR*455.7f/1000.0f);//�ȽϼĴ���ֵ����Сֵ��3��tSHRTIMER_CKʱ�ӣ����ֵ��0xFFFF - (1��tSHRTIMER_CK)
	comparecfg_para.compare_value = (uint32_t)((float32)SHRTIMER_CAR*485.7f/1000.0f);//�ȽϼĴ���ֵ����Сֵ��3��tSHRTIMER_CKʱ�ӣ����ֵ��0xFFFF - (1��tSHRTIMER_CK)

	shrtimer_slavetimer_waveform_compare_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, SHRTIMER_COMPARE2, &comparecfg_para);////����Slave_TIMER���εıȽϹ���
	comparecfg_para.compare_value = SHRTIMER_CAR/8.0f;//�ȽϼĴ���ֵ����Сֵ��3��tSHRTIMER_CKʱ�ӣ����ֵ��0xFFFF - (1��tSHRTIMER_CK)
    shrtimer_slavetimer_waveform_compare_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, SHRTIMER_COMPARE3, &comparecfg_para);////����Slave_TIMER���εıȽϹ���

	/* configures the ST2_CH0_O output of a Slave_TIMER2 work in waveform mode */
    shrtimer_channel_outputcfg_struct_para_init(&outcfg_para);
    outcfg_para.carrier_mode = SHRTIMER_CHANNEL_CARRIER_DISABLED;//ʹ�ܻ�����ز�ģʽ
    outcfg_para.deadtime_bunch = SHRTIMER_CHANNEL_BUNCH_ENTRY_REGULAR;//��ͻ��ģʽ����IDLE״̬ǰ�Ƿ��������ʱ��
    outcfg_para.fault_state = SHRTIMER_CHANNEL_FAULTSTATE_INACTIVE;//����ʱͨ�����״̬
    outcfg_para.idle_bunch = SHRTIMER_CHANNEL_BUNCH_IDLE_DISABLE;//ͨ���Ƿ���ͻ��ģʽ����
    outcfg_para.idle_state = SHRTIMER_CHANNEL_IDLESTATE_INACTIVE;//ͨ������Ŀ���״̬
    outcfg_para.polarity = SHRTIMER_CHANNEL_POLARITY_HIGH;//ͨ���������
    outcfg_para.reset_request = SHRTIMER_CHANNEL_RESET_CMP0 ;//����ͨ�������λ������¼�
    outcfg_para.set_request = SHRTIMER_CHANNEL_SET_PER;		//����ͨ�������λ������¼�	
    shrtimer_slavetimer_waveform_channel_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, SHRTIMER_ST2_CH0, &outcfg_para);//Slave_TIMER���ε�ͨ������
    shrtimer_slavetimer_waveform_channel_config(SHRTIMER0, SHRTIMER_SLAVE_TIMER2, SHRTIMER_ST2_CH1, &outcfg_para);

    shrtimer_timers_interrupt_enable(SHRTIMER0,SHRTIMER_SLAVE_TIMER2,SHRTIMER_MT_ST_INT_CMP1);
    shrtimer_timers_interrupt_enable(SHRTIMER0,SHRTIMER_SLAVE_TIMER2,SHRTIMER_MT_ST_INT_CMP2);
	/* configure the trigger source to ADC and the update source */
    shrtimer_adctrigcfg_struct_para_init(&adctrigcfg_para);
    adctrigcfg_para.update_source = SHRTIMER_ADCTRGI_UPDATE_ST2;
    adctrigcfg_para.trigger       = SHRTIMER_ADCTRGI13_EVENT_ST2CMP3;
    shrtimer_adc_trigger_config(SHRTIMER0, SHRTIMER_ADCTRIG_1, &adctrigcfg_para);
	#if 0
	/* enable output channel */
    shrtimer_output_channel_enable(SHRTIMER0, SHRTIMER_ST2_CH0);
    shrtimer_output_channel_enable(SHRTIMER0, SHRTIMER_ST2_CH1);
    /* enable a counter */
    shrtimer_timers_counter_enable(SHRTIMER0, SHRTIMER_ST2_COUNTER);
	#endif
}


static void adc_config(void)
{
    /* configure ADC mode */
    adc_mode_config(ADC_MODE_FREE);
    /* ADC scan mode function enable */
    adc_special_function_config(ADC0, ADC_SCAN_MODE, DISABLE);
    /* ADC continuous function disable */
    adc_special_function_config(ADC0, ADC_CONTINUOUS_MODE, DISABLE);
    /* configure ADC data alignment */
    adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);

    /* configure ADC inserted channel trigger */
    adc_external_trigger_source_config(ADC0, ADC_INSERTED_CHANNEL, ADC0_1_EXTTRIG_INSERTED_SHRTIMER_ADCTRG1);
    adc_external_trigger_config(ADC0, ADC_INSERTED_CHANNEL, ENABLE);  

    /* configure ADC inserted channel length */
    adc_channel_length_config(ADC0, ADC_INSERTED_CHANNEL, 1);
    /* configure ADC inserted channel */
    adc_inserted_channel_config(ADC0, 0, VOUT_24V_CHANNEL, ADC_SAMPLETIME_13POINT5);

	 /* 32 times sample, 5 bits shift */
    adc_oversample_mode_config(ADC0, ADC_OVERSAMPLING_ALL_CONVERT, ADC_OVERSAMPLING_SHIFT_5B, ADC_OVERSAMPLING_RATIO_MUL32);
    adc_oversample_mode_enable(ADC0);
	
    /* ADC external trigger disable */
    adc_interrupt_disable(ADC0, ADC_INT_EOIC);

	/* clear the ADC flag */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC);
	/* enable ADC interrupt */
    adc_interrupt_enable(ADC0, ADC_INT_EOIC);
    /* enable ADC interface */
    adc_enable(ADC0);

	delay_ms(1);
    /* ADC calibration and reset calibration */
    adc_calibration_enable(ADC0);


}


void Init_global_variable(void)
{

    reference_vout = 24.0f;
    Vout_sample = 0;
    pid_result = 0;
	
	pid_vout_calc_enable_flag = 0;
	pid_vout_enable = 0;
	vout_step = 0;
	g32carlvalue_last = SHRTIMER_CAR;
	g8trigenable = 0;
	convert_ratio = 3.3f*10.905f/4095.0f;//0.00831f;//3.3*10.31/4095
	
	g8runflag = 0;
	
	g8shake_flag = 0;
}







