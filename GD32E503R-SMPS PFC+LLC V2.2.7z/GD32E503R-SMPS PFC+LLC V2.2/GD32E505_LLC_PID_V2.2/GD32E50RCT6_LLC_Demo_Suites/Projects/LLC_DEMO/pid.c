/*!
    \file    pid.c
    \brief   pid controller configure file

    \version 2020-06-30, V1.0.0, demo for GD32E50x
*/

/*
    Copyright (c) 2019, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "pid.h"
#include "main.h"
#include "gd32e50x.h"
//#include <stdio.h>

float32 reference_vout;
float32 vin,vin_6v;
float32 SR_isense,SR_isense_bak,SR_isense_th;
float32 Vout_sample;
float32 vout_history_data[VOUT_HISTORY_DATA_NUM];
float32 convert_ratio;
uint8_t vout_step;
float32 average_vout;
float32 average_isense;
uint8_t sample_index;
uint8_t skip_pid_calculate;
uint8_t flag_change_pid_para;
uint8_t SR_sample_time;

float32 pid_result;
uint8_t pid_vout_calc_enable_flag;
uint8_t pid_vout_enable;
uint32_t g32carlvalue_last;
uint8_t g8trigenable, g8powercheck, g8runflag;

pid_parameter_float llc_voltage;


void pid_vout_calc_enable(void)
{
	__IO static float32 error_u,error_i,actual_vout;
	uint16_t m16pwm;
	
	if(1 == pid_vout_enable)
	{
		pid_result = pid_regulation_float(reference_vout,Vout_sample,&llc_voltage);
		g32carlvalue_last = (uint32_t)((float32)SHRTIMER_HPCK*1000.0f/pid_result);
	}
}

void pfc_pid_init(void){


    llc_voltage.kp = 0.25f;
    llc_voltage.kp_div = 0.5f;
    llc_voltage.ki = 100000;
    llc_voltage.ki_div = 100000;
    llc_voltage.ki_sum = 4000000;
    llc_voltage.upper_limit = 110.0f;//  0A??��?3?��??��
    llc_voltage.lower_limit = 74.0f;  //  20A??
    llc_voltage.error  = 0;
    llc_voltage.output = 0;
    llc_voltage.ki_sum_upper_limit = llc_voltage.upper_limit * llc_voltage.ki_div;
    llc_voltage.ki_sum_lower_limit = llc_voltage.lower_limit * llc_voltage.ki_div;
    llc_voltage.direction_flag = 0;

}

float32 pid_regulation_float(float ref, float now, pid_parameter_float *pid_para)
{
    float output_temp = 0;

    /* calculate the error */
    pid_para->error = (now - ref);
    pid_para->i_index = 1;
    pid_para->ki_sum += pid_para->error * pid_para->ki;

    /* integration anti-windup */
    if(pid_para->ki_sum > pid_para->ki_sum_upper_limit){
        pid_para->ki_sum = pid_para->ki_sum_upper_limit;
    }else if(pid_para->ki_sum < pid_para->ki_sum_lower_limit){
        pid_para->ki_sum = pid_para->ki_sum_lower_limit;
    }

    output_temp = pid_para->error * pid_para->kp / pid_para->kp_div + pid_para->i_index*pid_para->ki_sum / pid_para->ki_div;

    /* output anti-windup */
    if(output_temp < pid_para->lower_limit){
        output_temp = pid_para->lower_limit;
    }else if(output_temp > pid_para->upper_limit){
        output_temp = pid_para->upper_limit;
    }

    if(pid_para->direction_flag){
		#if 0
        if(DIRECTION_CW == direction){
            output_temp = -output_temp;
        }
		#endif
    }
    
    pid_para->output = output_temp;

    return (pid_para->output);
}

  