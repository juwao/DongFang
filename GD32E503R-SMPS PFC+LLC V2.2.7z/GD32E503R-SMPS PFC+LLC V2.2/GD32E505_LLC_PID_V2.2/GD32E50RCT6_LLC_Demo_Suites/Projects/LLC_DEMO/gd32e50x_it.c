/*!
    \file    gd32e50x_it.c
    \brief   interrupt service routines
    
    \version 2020-06-30, V1.0.0, demo for GD32E50x
*/

/*
    Copyright (c) 2020, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "gd32e50x_it.h"
#include "main.h"
#include "pid.h"
#include "debug.h"


mc_usart_debug debug_data;


/*!
    \brief      this function handles NMI exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void NMI_Handler(void)
{
}

/*!
    \brief      this function handles HardFault exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void HardFault_Handler(void)
{
    /* if Hard Fault exception occurs, go to infinite loop */
    while (1){
    }
}

/*!
    \brief      this function handles SVC exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void SVC_Handler(void)
{
}

/*!
    \brief      this function handles PendSV exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void PendSV_Handler(void)
{
}

static void _delay(uint32_t time)
{
    __IO uint32_t i;
    for(i=0; i<time*2; i++){
    }
}


/*!
    \brief      this function handles SHRTIMER_IRQ3 interrupt request
    \param[in]  none
    \param[out] none
    \retval     none
*/

void SHRTIMER_IRQ3_IRQHandler(void)
{
	
	if(SET == shrtimer_timers_flag_get(SHRTIMER0,SHRTIMER_SLAVE_TIMER2,SHRTIMER_MT_ST_FLAG_CMP1))
    {// Q1��Q4
    	#if 1
    	gpio_bit_reset(SR2_CTR_PORT , SR2_CTR_PIN);   //  �ض�Q4
		_delay(3);   //  ���ߵ�����ʱ������
        gpio_bit_set(SR1_CTR_PORT , SR1_CTR_PIN);   //  ��Q3
		#endif
		shrtimer_timers_flag_clear(SHRTIMER0,SHRTIMER_SLAVE_TIMER2,SHRTIMER_MT_ST_FLAG_CMP1);
    }
    else if(SET == shrtimer_timers_flag_get(SHRTIMER0,SHRTIMER_SLAVE_TIMER2,SHRTIMER_MT_ST_FLAG_CMP2))
    {// Q2��Q3
    	#if 1
    	gpio_bit_reset(SR1_CTR_PORT , SR1_CTR_PIN);
		_delay(3);
        gpio_bit_set(SR2_CTR_PORT , SR2_CTR_PIN);
		#endif
        shrtimer_timers_flag_clear(SHRTIMER0,SHRTIMER_SLAVE_TIMER2,SHRTIMER_MT_ST_FLAG_CMP2);
    }
    
}




/*!
    \brief      this function handles ADC0_1 interrupt
    \param[in]  none
    \param[out] none
    \retval     none
*/
void ADC0_1_IRQHandler(void)
{
	uint16_t vout_adc_value;
	float32 Vout_sample_temp;
	uint8_t m8i;
	
    /* clear the ADC flag */
    adc_interrupt_flag_clear(ADC0, ADC_INT_FLAG_EOIC);
    /* read ADC inserted group data register */
    vout_adc_value = adc_inserted_data_read(ADC0, ADC_INSERTED_CHANNEL_0);
    Vout_sample_temp= (float32)vout_adc_value * convert_ratio; 
	vout_step ++;
	#if 1
	if((g8trigenable == 1)&&(vout_step >= 5)&&(g8runflag == 1))
	{
		Vout_sample = Vout_sample_temp;
		vout_step = 0;
		pid_vout_calc_enable_flag = 1;
	}
	if((Vout_sample_temp < reference_vout * 0.85f)&&(g8powercheck == 0))
	{
		pid_vout_calc_enable_flag = 0;
		vout_step = 0;
	}
	else
	{
		g8powercheck = 1;
		g8runflag = 1;
	}
	if((PFC_FAULT_CONDITION == g8cmd)&&(Vout_sample_temp < reference_vout * 0.1f))
	{
		LLC_STATUS_Set(LLC_DEFAULT_STATUS);
		g32prevent_shake = 0;
		g8powercheck = 0;
	}
	#if 1
	if((pid_vout_calc_enable_flag == 1)&&(Vout_sample_temp < reference_vout * 0.1f))
	{
		LLC_STATUS_Set(LLC_DEFAULT_STATUS);
		g32prevent_shake = 0;
		g8powercheck = 0;
	}
	#endif	
	#endif
	#if 0
	debug_data.data1 =(uint16_t)(2250) ;//duty_set;//TIMER_CH3CV(TIMER2);//current_reference;//speed_count_temp/10;//speed_rmin;
    debug_data.data2 = (uint16_t)(Vout_sample*100);;//(pfc_samp.CURRENT*100);//duty_set;//speed_rmin;//duty_set;//stop_flag*10;
    debug_data.data3 = (uint16_t)200;//pfc_samp.VAC;
    debug_usart_data_transfer(debug_data);
	#endif
	
}




/*!
    \brief      this function handles external lines 5 to 9 interrupt request
    \param[in]  none
    \param[out] none
    \retval     none
*/
void EXTI5_9_IRQHandler(void)
{
	exti_interrupt_flag_clear(LLCKEY_EXTI_LINE);
	if(LLC_DEFAULT_STATUS == g8cmd)
	{
		LLC_STATUS_Set(PFC_RIGHT_CONDITION);
	}

}

