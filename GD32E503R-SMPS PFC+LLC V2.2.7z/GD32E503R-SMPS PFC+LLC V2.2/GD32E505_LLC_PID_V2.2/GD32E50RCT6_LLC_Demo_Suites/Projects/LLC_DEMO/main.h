/*!
    \file    main.h
    \brief   SMPS project

    \version 2020-06-30, V1.0.0, demo for GD32E50x
*/
/*
    Copyright (c) 2019, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include "systick.h"
#define LLC_DEFAULT_STATUS                            ((uint8_t)0x00)
#define PFC_RIGHT_CONDITION                           ((uint8_t)0x01)
#define LLC_RUN_STATUS						  		  ((uint8_t)0x02)
#define LLC_UPDATE_FREQUENCE						  ((uint8_t)0x03)
#define PFC_FAULT_CONDITION                           ((uint8_t)0x04)

#define MAX_PWM_DUTY                          (MCU_HO_DUTY_MAX * 10)
#define MIN_PWM_DUTY                          (MCU_HO_DUTY_MIN * 10)

/* V,I,T limit configuration */
#define VIN_LIMIT_MAX                          ((float)(44.0f)) 
#define VIN_LIMIT_MIN                          ((float)(18.0f))

#define VOUT_LIMIT_MAX                         ((float)(32.0f)) 
#define VOUT_LIMIT_MIN                         ((float)(0))


    
/* pin configuration */
/* SHRTIMER PWM_OUT  pin configuration */
#define HO_PWM_PORT                           GPIOB
#define HO_PWM_PIN                            GPIO_PIN_12
#define LO_PWM_PORT                           GPIOB
#define LO_PWM_PIN                            GPIO_PIN_13

/* SHRTIMER configuration */
/* SHRTIMER timing configuration */

#define FREQ_PWM                              ((uint32_t)84U) 
//@ff200V  2Ϊ��λ���ڣ�80v�Ļ�������Ҫ��
#define PERIOD_PWM                            ((uint32_t)(1000000U / FREQ_PWM))    //unit is ns
#define SHRTIMER_CK                           ((uint32_t)180U)                               //unit is MHz
#define DLL_VALUE                             ((uint32_t)16U)
#define SHRTIMER_HPCK                         ((uint32_t)(SHRTIMER_CK * DLL_VALUE))
#define PSC_VALUE                             ((uint32_t)1U)
#define SHRTIMER_PSCCK                        ((uint32_t)(SHRTIMER_HPCK / PSC_VALUE))        //unit is MHz :11520MHZ
#define SHRTIMER_CAR                          ((uint32_t)SHRTIMER_HPCK*1000U/FREQ_PWM)       //57600
#define DEADTIME_RIS                          ((uint32_t)500U)                                //unit is ns
#define DEADTIME_RIS_VAL                      ((uint32_t)(DEADTIME_RIS*SHRTIMER_HPCK/1000U))
#define DEADTIME_FAL                          ((uint32_t)500U)                                //unit is ns
#define DEADTIME_FAL_VAL                      ((uint32_t)(DEADTIME_FAL*SHRTIMER_HPCK/1000U))

#define DEADTIME_DUTY_RIS                     ((float)((float)DEADTIME_RIS / (float)PERIOD_PWM * 100))
#define DEADTIME_DUTY_FAL                     ((float)((float)DEADTIME_FAL / (float)PERIOD_PWM * 100))

/* duty of driver HO pin(8~92)/  (8) is measured by open loop test*/
#define DRV_DUTY_MAX                          ((float)(100.0f - DEADTIME_DUTY_RIS))                 
#define DRV_DUTY_MIN                          ((float)(DEADTIME_DUTY_FAL))   
    
/* duty that fact vout(vout = duty*vin) */
#define ACT_DUTY_MAX                          ((float)(DRV_DUTY_MAX))                 
#define ACT_DUTY_MIN                          ((float)(DRV_DUTY_MIN))  
    
/* duty of mcu HO pin (0~84)*/
#define MCU_HO_DUTY_MAX                      ((float)(DRV_DUTY_MAX - 8.0f))
#define MCU_HO_DUTY_MIN                      ((float)(DRV_DUTY_MIN - 8.0f))
    
/* duty of pid (8~92)*/
#define PID_DUTY_MAX                         ((float)(ACT_DUTY_MAX))
#define PID_DUTY_MIN                         ((float)(ACT_DUTY_MIN))
    
#define MARGIN_DUTY_FOR_SAFE                 ((float)(0.0f))






/* adc channel configuration */

/* ADC regular channel configuration */   

#define I_SR1_PIN                           GPIO_PIN_0
#define I_SR1_PORT                          GPIOB
#define I_SR1_CHANNEL                       ADC_CHANNEL_8

#define I_SR2_PIN                           GPIO_PIN_1
#define I_SR2_PORT                          GPIOB
#define I_SR2_CHANNEL                       ADC_CHANNEL_9

/* ADC inserted channel configuration */
#define CURRENT_S2_PIN                      GPIO_PIN_2
#define CURRENT_S2_PORT                     GPIOA
#define CURRENT_S2_CHANNEL                  ADC_CHANNEL_2

#define CURRENT_S1_PIN                      GPIO_PIN_1
#define CURRENT_S1_PORT                     GPIOA
#define CURRENT_S1_CHANNEL                  ADC_CHANNEL_1


#define VOUT_24V_PIN                        GPIO_PIN_0
#define VOUT_24V_PORT                       GPIOC
#define VOUT_24V_CHANNEL                    ADC_CHANNEL_10

#define PFC_TEMP_PIN                        GPIO_PIN_1
#define PFC_TEMP_PORT                       GPIOC
#define PFC_TEMP_CHANNEL                    ADC_CHANNEL_11

#define LLC_TEMP1_PIN                       GPIO_PIN_2
#define LLC_TEMP1_PORT                      GPIOC
#define LLC_TEMP1_CHANNEL                   ADC_CHANNEL_12

#define LLC_TEMP2_PIN                       GPIO_PIN_3
#define LLC_TEMP2_PORT                      GPIOC
#define LLC_TEMP2_CHANNEL                   ADC_CHANNEL_13


// VIN Vtemp Vtemp2
#define ADC_REGULAR_CHANNEL_NUM             1     


/*SR CTR configuration*/
#define SR1_CTR_PIN                         GPIO_PIN_15 
#define SR1_CTR_PORT                        GPIOB 

#define SR2_CTR_PIN                         GPIO_PIN_14  
#define SR2_CTR_PORT                        GPIOB

/*BUTTON INPUT configuration*/
#define LLCKEY_BUTTON_PIN						GPIO_PIN_9  
#define LLCKEY_BUTTON_PORT						GPIOB
#define LLCKEY_EXTI_LINE                  		EXTI_9
#define LLCKEY_EXTI_PORT_SOURCE           		GPIO_PORT_SOURCE_GPIOB
#define LLCKEY_EXTI_PIN_SOURCE            		GPIO_PIN_SOURCE_9
#define LLCKEY_EXTI_IRQn                  		EXTI5_9_IRQn


/*LED configuration*/
#define LED1_PIN                         	GPIO_PIN_4 
#define LED1_PORT                        	GPIOC
#define LED2_PIN                         	GPIO_PIN_5  
#define LED2_PORT                        	GPIOC

/*DEBUG PIN*/
#define LLC_READY_PIN						GPIO_PIN_7
#define LLC_READY_PORT						GPIOC
#define LLC_RES_PIN							GPIO_PIN_8 
#define LLC_RES_PORT						GPIOC
#define DISCHARGE_PIN						GPIO_PIN_15
#define DISCHARGE_PORT						GPIOC


typedef enum
{
	SR1_SAMPLE_ON = 0,
	SR1_SAMPLE_OFF = 1,
	SR2_SAMPLE_ON = 2,
	SR2_SAMPLE_OFF = 3,
	SR12_SAMPLE_OFF = 4,
}SR_SAMPLE_TYPE;

extern uint8_t g8cmd;
extern uint32_t g32prevent_shake;
extern uint8_t g8shake_flag;

/*LLC_UPDATE_Frequence configuration*/
void LLC_UPDATE_Frequence(uint32_t m32carlvalue_last);
/*LLC_STATUS_Set configuration*/
void LLC_STATUS_Set(uint8_t m8status);
/* GPIO configuration */
static void gpio_config(void);
/* RCU configuration */
static void rcu_config(void);
/* NVIC configuration */
static void nvic_config(void);
/*configure the TIMER peripheral*/
void timer_config(void);
/*initilize the EXTI configuration of the key*/
static void key_exti_init(void);
/* SHRTIMER configuration */
static void shrtimer_config(void);
/* ADC configuration */
static void adc_config(void);
/* ADC dma configuration */
static void dma_config(void); 
/* Initial global variable*/
void Init_global_variable(void);
void LLC_Soft_Start(void);
#endif /* MAIN_H */
