
/*
    Copyright (c) 2019, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#ifndef PID_H
#define PID_H
#include <stdio.h>


#define AVERAGE_VOUT_DISPLAY 
#define VOUT_HISTORY_DATA_NUM  ((uint8_t)10U)

#define AVERAGE_ISENSE_DISPLAY 
#define ISENSE_HISTORY_DATA_NUM  ((uint8_t)10U)

typedef    float    float32;
typedef    double   float64;

typedef unsigned          char uint8_t;
typedef unsigned short     int uint16_t;
typedef unsigned           int uint32_t;



/* the structure of pid parameter */
typedef struct{
    float32 kp;                                                                /* the proportional factor */
    float32 kp_div;                                                            /* the proportional division factor */
    float32 ki;                                                                   /* the integral factor */
    float32 ki_div;                                                            /* the integral division factor */
    uint8_t i_index;                                                            /* the integral separation index */
    float32 ki_sum;                                                               /* the sum of the integral term */
    float32 ki_sum_upper_limit;                                                 /* the upper limit of integral term */
    float32 ki_sum_lower_limit;                                                 /* the lower limit of integral term */
    float32 upper_limit;                                                        /* the upper limit of ouput */
    float32 lower_limit;                                                        /* the lower limit of ouput */
    float32 error;                                                              /* the error of the input */
    float32 output;                                                             /* the output varialbe */
    uint8_t direction_flag;                                                     /* the sign of the output variable */
}pid_parameter_float;



extern float32 reference_vout;
extern float32 vin,vin_6v;
extern float32 SR_isense;
extern float32 SR_isense_bak;
extern float32 SR_isense_th;
extern float32 Vout_sample;
extern float32 vout_history_data[VOUT_HISTORY_DATA_NUM];
extern float32 convert_ratio;
extern uint8_t vout_step;
extern float32 average_vout;
extern float32 average_isense;

extern uint8_t sample_index;
extern uint8_t skip_pid_calculate;
extern uint8_t flag_change_pid_para;
extern uint8_t SR_sample_time;



extern float32 pid_result;
extern uint8_t pid_vout_calc_enable_flag;
extern uint8_t pid_vout_enable;
extern uint32_t g32carlvalue_last;
extern uint8_t g8trigenable;
extern uint8_t g8powercheck;
extern uint8_t g8runflag;
extern pid_parameter_float llc_voltage;



void pid_vout_calc_enable(void);
void pfc_pid_init(void);
float32 pid_regulation_float(float ref, float now, pid_parameter_float *pid_para);
#endif /* PID_H */