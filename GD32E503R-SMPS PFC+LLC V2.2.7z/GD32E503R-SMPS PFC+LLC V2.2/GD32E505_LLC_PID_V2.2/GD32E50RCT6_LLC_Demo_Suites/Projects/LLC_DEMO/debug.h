/*!
    \file    debug.h
    \brief   the header file of debug module

    \version 2019-07-15, V1.0.0, FOC demo
    \version 2020-12-15, V1.1.0, FOC demo
    \version 2021-02-01, V1.2.0, FOC demo
    \version 2021-08-16, V1.3.0, FOC demo
*/

/*
    Copyright (c) 2021, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#ifndef DEBUG_H
#define DEBUG_H

#include "gd32e50x.h"


/* debug function */
/* debug buffer size configuration, 12 bytes per frame */
#define DEBUG_BUFFER_SIZE                   (600U)
/* usart configuration */
//#define USART_DEBUG_ENABLE
#define USART_BPS                           (460800U)                           /* the baudrate of the usart */
#define DEBUG_USART                         USART1
#define DEBUG_USART_CLOCK                   RCU_USART1
#define USART_RX_PORT                       GPIOA
#define USART_RX_PIN                        GPIO_PIN_3
#define USART_TX_PORT                       GPIOA
#define USART_TX_PIN                        GPIO_PIN_2

/* the structure of debug */
typedef struct
{
    int16_t data1;
    int16_t data2;
    int16_t data3;
    int16_t data4;
    int16_t data5;
    int16_t data6;
    int16_t data7;
    int16_t data8;
}mc_usart_debug;

/* initialize the hardware of debug function */
void debug_init(void);
/* data transmission with USART */
void debug_usart_data_transfer(mc_usart_debug data);
/* data transmission with DAC */
void debug_dac_data_transfer(int16_t a, int16_t b);

#endif /* DEBUG_H */
